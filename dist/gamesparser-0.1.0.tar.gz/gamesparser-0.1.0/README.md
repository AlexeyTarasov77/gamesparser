# Games parser, which can parse game sales from xbox and psn websites, collecting prices for different regions
