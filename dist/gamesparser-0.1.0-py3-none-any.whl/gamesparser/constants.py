PSN_PARSE_REGIONS = ("ua", "tr")
XBOX_PARSE_REGIONS = ("ar", "us", "tr")
XBOX_SALES_URL = "https://www.xbox-now.com/en/deal-list"
PSN_SALES_URL = "https://store.playstation.com/{region}/category/3f772501-f6f8-49b7-abac-874a88ca4897/"
